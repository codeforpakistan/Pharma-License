<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

      <?php $this->load->view('templates/alerts');?>

      <!-- <h1>
        <?php echo ucwords(str_replace('_', ' ', $page_title)); ?>
        <small><?php echo ucwords(str_replace('_', ' ', $description)); ?></small>
      </h1> -->

    </section>

    <!-- Main content -->

    <!-- Main content -->
    <section class="content">

      <div class="row">

        <div class="col-md-12">
  <?php //$getInspection = $this->global->getRecordByArray('tbl_inspection', array('id' => $id));?>

  <?php $all = $this->global->getRecordByArray('tbl_form_8a', array('id' => $id));?>

  <?php $getProprietor = $this->global->getRecordByArray('tbl_proprietor', array('id' => $all['tbl_proprietor_id']));?>
  <?php $getPharmacist = $this->global->getRecordByArray('tbl_pharmacist', array('id' => $all['tbl_pharmacist_id']));?>
  <?php $getDates = $this->global->getRecordByArray('tbl_application_renewel', array('tbl_name' => 'tbl_form_8a', 'tbl_name_id' => $id));?>
  <!-- personal info start -->
<div class="box">
  <!-- /.box-header -->
  <div class="box-body">
    <div class="row">
      <!-- /.col -->
      <div class="col-md-12">
        <div class="table-responsive">
          <table class="table table-condensed">
            <tr>

              <td class="tdva text-left"><img src="<?php echo base_url() . IMG_UPLOAD_PATH . 'pharmacist/' . $getPharmacist['image']; ?>" height="100" width="100" class="img-thumbnail"> <br>Qualified Person</td>
              <!-- <td class="tdvb text-center">Form - 12 <br><b><u> Provisional License</u></b></td> -->
              <td class="tdvb text-center"><b><u>Form - 12</u></b></td>
              <td class="tdvb text-right">
                <img class="img-thumbnail" height="120px" width="120px" src="<?php echo base_url() . IMG_UPLOAD_PATH . 'qr_codes/' . $all['qr_code']; ?>">
                <br>License: <u>Pharmacy/<?php echo date('y') . $all['id'] . '/' . date('m'); ?></u> <br> Date: <u><?php echo date('d/m/Y'); ?></u></td>
            </tr>
            <tr>
              <td colspan="3" class="tdvb text-center">{(See Rules 15(4))}</td>
            </tr>
            <tr>
              <td colspan="3" class="tdva text-center">LICENSE TO SELL, STOCK AND EXHIBIT FOR SALE AND DISTRIBUTE DRUGS BY WAY OF RETAIL SALE</td>
            </tr>
            <tr>
              <td colspan="3" class="tdvb text-justify">
                <ol>
                <li>
                License to sell drugs in Pharmacy, <b><u><?php echo $getProprietor['name']; ?> S/O <?php echo $getProprietor['father_name']; ?> Prop: M/S <?php echo $getProprietor['business_name']; ?> </u></b> is hereby licensed to compound ot prepare on prescription the drugs and distribute drugs by way of retail sale on the premises situated at <b><u> <?php echo ucwords($getProprietor['business_address']); ?> </u></b> subject to conditions specified below and to the provision of Drugs Act, 1976 and the rules made there under.
                </li>

                <br>
                <li>This License will be force for two years from the date given below:</li>
                <br>


                <li>Name(s) of Qualified Person(s) <b><u><?php echo $getPharmacist['name']; ?> S/O <?php echo $getPharmacist['father_name']; ?></u></b></li>
                <br>

                <li>Registration No <b><u><?php echo $getPharmacist['pharmacy_reg_no']; ?></u></b> with
                  <?php if ($getPharmacist['tbl_pharmacist_category_id']) {?>
                <?php $getCategory = $this->global->getRecordByArray('tbl_pharmacist_category', array('id' => $getPharmacist['tbl_pharmacist_category_id']));?>

                  <u><b><?php echo $getCategory['name']; ?></u></b>
                <?php } else {?>
                  <u><b><?php echo $getPharmacist['category']; ?></u></b>
                <?php }?>

                </li>
                <br>

                <li>Addresses of Godown/where drugs shell be store.</li>
                <br>
<?php $issue_date = date('d-m-Y', strtotime($getDates['issue_date']));?>
<?php $expiry_date = date('d-m-Y', strtotime($getDates['expiry_date']));?>
                <li>From <b><u><?php echo $issue_date; ?> / <?php echo $expiry_date; ?></u></b></li>
                <br>

                <li>Dated: <u><?php echo date('d/m/Y'); ?></u></li>

              </td>
            </tr>
            <tr>
              <td colspan="3" class="tdvb text-right">
                <br>
                <b><u>LICENSING AUTHORITY</u></b>
              </td>
            </tr>
            <tr>
              <td colspan="3" class="tdvb text-center">
                <b><u>
                CONDITIONS OF THE LICENSE</u></b>
                <br>
              </td>
            </tr>
            <tr>
              <td colspan="3" class="tdvb text-justify">
                <ol><li>
                This license shall be displayed in a prominent place in part of the premises open to the public.</li>
                <li>
                The License shall comply with the provisions of Drugs Act, 1976 and the rules made there under for the time being in force.</li>
                <li>
                The License shall report for with to the Licensing authority any change in the qualifief staff Incharge.
                </li>
                <li>
                No drug requiring special storage conditions of temperature and humidity shall be sold unless the precaution necessary for preserving the proprietors of the contents have been observed throughout the period during which it has been possession of the license.
              </li>
                </ol>
              </td>
            </tr>
          </table>
        </div>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
</div>
</div>



  </div>

      <!-- /.box -->

        <div class="row">
         <!-- /.col -->
        <div class="col-xs-12 text-right no-print">
          <button type="button" name="print" value="print" class="btn btn-success  btn-sm" onclick="window.print();"><i class="fa fa-print"> </i> Print</button>
    <a href="<?php echo base_url(dashboard); ?>" class="btn btn-danger  btn-sm" type="button"> <i class="fa fa-chevron-left"> </i> Cancel/Back</a>

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>

    <!-- /.content -->
  </div>
<style type="text/css">

  hr {
    margin-top: 8px;
    margin-bottom: 8px;
    border: 1;
    border-top: 1px solid #008E4B;
}
</style>





<style type="text/css">

ol {
    display: block;
    list-style-type: decimal;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    padding-inline-start: 30px;
}
  .table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td {
    border-top: 0px solid #f4f4f4;
}
  .box{
    border-top: 0;
  }
.tdva{
  height: 40px;
  width: 25%;
  font-weight: bold;
  vertical-align: middle !important;
}
.tdvb{
  height: 40px;
  width: 25%;
  vertical-align: middle !important;
}
</style>

